export class PersonListItem {

    private _age : number;
    public get age() : number {
        return this._age;
    }
    public set age(v : number) {
        this._age = v;
    }
   
   private _firstName : string;
   public get firstName() : string {
       return this._firstName;
   }
   public set firstName(v : string) {
       this._firstName = v;
   }
   
   
   private _lastName : string;
   public get lastName() : string {
       return this._lastName;
   }
   public set lastName(v : string) {
       this._lastName = v;
   }
   
   private _gender : string;
   public get gender() : string {
       return this._gender;
   }
   public set gender(v : string) {
       this._gender = v;
   }
   
   private _id : number;
   public get id() : number {
       return this._id;
   }
   public set id(v : number) {
       this._id = v;
   }
   
   private _email : string;
   public get email() : string {
       return this._email;
   }
   public set email(v : string) {
       this._email = v;
   }
   
   
   private _birthsday : Date;
   public get birthsday() : Date {
       return this._birthsday;
   }
   public set birthsday(v : Date) {
       this._birthsday = v;
   }
   
   
   private _income : number;
   public get income() : number {
       return this._income;
   }
   public set income(v : number) {
       this._income = v;
   }
   
   public toTableRow():string{
       return '<tr><td>'
            +this.id
            +'</td><td>'
            +this._firstName
            +'</td><td>'
            +this._lastName
            +'</td><td>'
            +this.gender
            +'</td><td>'
            +this.email
            +'</td><td>'
            +this.age
            +'</td><td>'
            +this.birthsday.toISOString()
            +'</td><td>'
            +this.income
            +'</td></tr>'
   }

}