
import { people } from './data';
import { PersonListItem } from "../person-list-item";

export class PagingInfo {
    constructor(public page: number, public count: number) {
    }
}

export class PersonService {

    people: Array<PersonListItem> = [];

    public getPeople(pagingInfo: PagingInfo): Array<PersonListItem> {
        //some logic will be here
        this.people = people.map(x => {
            let person = new PersonListItem();
            person.firstName = x.firstName;
            person.lastName = x.lastName;
            person.gender = x.gender;
            person.email = x.email;
            person.income = +x.income
            person.age = x.age;
            person.birthsday = new Date(x.birthsday);
            person.id = x.id;
            return person;
        });

        let begin = pagingInfo.page - 1;
        if (begin < 0) begin = 0;
        return this.people.slice(begin * pagingInfo.count, begin * pagingInfo.count + pagingInfo.count);
    }
}

var service = new PersonService();

console.log(service.getPeople(new PagingInfo(1, 5)));